$(function() {
    $(".js-masked").inputmask({"mask": "+7 (999) 999-99-99"});   
})